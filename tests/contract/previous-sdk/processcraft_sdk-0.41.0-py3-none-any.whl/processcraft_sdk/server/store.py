"""An app's own SQLite database and the base class for module stores.

Every module of an app owns its tables and declares them in a ``SCHEMA`` string. The
``Database`` applies each module schema once, in dependency order, so a fresh
file and an existing installation converge on the same structure. ``recorded_at`` stamps the
rows written in a block with a past moment (a demo's story).

Migrations only go forward, so a database written by a newer version of the app is never opened
by an older one: given the app's ``version``, ``Database`` stamps the file with it
(``PRAGMA user_version``) and refuses, with ``SchemaTooNew``, a file stamped by a later version.
Going back a version restores the data of its backup instead (``docs/operations.md``).
"""

from __future__ import annotations

import json
import re
import sqlite3
import threading
from collections.abc import Iterator
from contextlib import contextmanager
from contextvars import ContextVar
from datetime import datetime
from pathlib import Path
from typing import Any

from processcraft_sdk.utc import normalize_times, utc_iso

_CLOCK: ContextVar[datetime | None] = ContextVar("processcraft_sdk_store_clock", default=None)


@contextmanager
def recorded_at(moment: datetime) -> Iterator[None]:
    """Stamp every row written in this block with ``moment`` (a demo's story only)."""

    token = _CLOCK.set(moment)
    try:
        yield
    finally:
        _CLOCK.reset(token)


_SEMVER = re.compile(r"^(\d{1,3})\.(\d{1,3})\.(\d{1,3})(?:[-+].*)?$")


def schema_stamp(version: str) -> int:
    """The ``user_version`` stamp of an app version: ``0.10.3`` -> ``10003``, ``1.2.0`` ->
    ``1002000`` (major, minor and patch up to 999 each)."""

    match = _SEMVER.match(version.strip())
    if not match:
        raise ValueError(f"not a version like 1.2.3: {version!r}")
    major, minor, patch = (int(part) for part in match.groups())
    return major * 1_000_000 + minor * 1_000 + patch


def stamp_version(stamp: int) -> str:
    """The version a ``user_version`` stamp stands for (``schema_stamp`` reversed)."""

    return f"{stamp // 1_000_000}.{stamp // 1_000 % 1_000}.{stamp % 1_000}"


UTC_TIMES = "utc-times-2026-10-23"


class SchemaTooNew(RuntimeError):
    """The database was written by a later version of the app: this one must not open it."""

    def __init__(self, path: Path, found: int, mine: int):
        super().__init__(
            f"{path.name} was written by version {stamp_version(found)} of this app and this is "
            f"version {stamp_version(mine)}: an older version never opens a newer database. "
            "Go back with the backup taken before the update (install.sh --rollback), "
            "or install the newer version again."
        )
        self.found = found
        self.mine = mine


class Database:
    """One SQLite file shared by all module stores of an app's installation.

    ``version`` (the app's version) turns on the schema stamp: the file is stamped with it and a
    file stamped by a later version raises ``SchemaTooNew``.
    """

    def __init__(self, path: str | Path, *, version: str | None = None):
        self.path = Path(path).expanduser().resolve()
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.lock = threading.RLock()
        self._applied: set[str] = set()
        if version is not None:
            self._check_stamp(schema_stamp(version))
        self._utc_once()

    def _utc_once(self) -> None:
        """Every stored time in UTC (2026-10-23): rows written before are rewritten once."""

        with self.lock, self.connect() as connection:
            connection.execute(
                "CREATE TABLE IF NOT EXISTS sdk_migrations (name TEXT PRIMARY KEY, applied_at TEXT)"
            )
            done = connection.execute(
                "SELECT 1 FROM sdk_migrations WHERE name = ?", (UTC_TIMES,)
            ).fetchone()
            if done is None:
                normalize_times(connection)
                connection.execute(
                    "INSERT OR IGNORE INTO sdk_migrations (name, applied_at) VALUES (?, ?)",
                    (UTC_TIMES, utc_iso()),
                )

    def _check_stamp(self, mine: int) -> None:
        with self.lock, self.connect() as connection:
            found = int(connection.execute("PRAGMA user_version").fetchone()[0])
            if found > mine:
                raise SchemaTooNew(self.path, found, mine)
            if found < mine:
                connection.execute(f"PRAGMA user_version = {int(mine)}")

    def connect(self) -> sqlite3.Connection:
        connection = sqlite3.connect(self.path, timeout=30)
        connection.row_factory = sqlite3.Row
        connection.execute("PRAGMA foreign_keys = ON")
        connection.execute("PRAGMA journal_mode = WAL")
        connection.execute("PRAGMA busy_timeout = 30000")
        return connection

    def apply_schema(self, owner: str, schema: str) -> None:
        """Create the tables declared by one module, idempotently."""

        if owner in self._applied:
            return
        with self.lock, self.connect() as connection:
            connection.executescript(schema)
        self._applied.add(owner)


class Store:
    """Base class giving module stores the shared connection helpers."""

    SCHEMA = ""
    # Kept for apps that still name it: every time ``_now`` writes has milliseconds (utc_iso).
    TIMESPEC = "milliseconds"

    def __init__(self, db: Database):
        self.db = db
        if self.SCHEMA:
            db.apply_schema(type(self).__qualname__, self.SCHEMA)

    @property
    def path(self) -> Path:
        return self.db.path

    @property
    def _lock(self) -> threading.RLock:
        return self.db.lock

    def _connect(self) -> sqlite3.Connection:
        return self.db.connect()

    @classmethod
    def _now(cls) -> str:
        """Now (or the demo's clock) as ``2026-10-23T14:05:09.123Z`` (``processcraft_sdk.utc``)."""

        return utc_iso(_CLOCK.get())

    @staticmethod
    def _json(value: Any) -> str:
        return json.dumps(value, ensure_ascii=False, default=str)

    @staticmethod
    def _loads(value: str | None, default: Any) -> Any:
        if not value:
            return default
        try:
            return json.loads(value)
        except json.JSONDecodeError:
            return default

    @staticmethod
    def _row_with_json(
        row: sqlite3.Row,
        fields: dict[str, tuple[str, Any]],
    ) -> dict[str, Any]:
        item = dict(row)
        for output_name, (column_name, default) in fields.items():
            raw = item.pop(column_name, None)
            try:
                item[output_name] = json.loads(raw) if raw else default
            except json.JSONDecodeError:
                item[output_name] = default
        return item
