"""What an app adds to PlantCraft, declared once in its ``app.toml`` (``docs/app-standard.md``,
section 4b).

A new app must reach every place of the platform without a change to the platform. So an app
says in ``[contributes]`` what PlantCraft draws for it, and in ``[[publishes.series]]`` the
series it writes to the Historian; PlantCraft keeps the declarations in its registry (one per
app, ``PUT /api/v1/contributions``, sent by the SDK's server when the app starts, beside the
event catalog) and every screen reads the registry instead of asking each app::

    [[contributes.llm]]                  # a use of a language model (Setup > Language models)
    id = "algorithm-draft"
    title = "Draft an algorithm"
    description = "Builds an algorithm from what a person describes."
    reads = "The description and the block catalog; no plant data."
    default = "default"                  # the default model, or "off" until an admin picks one

    [[contributes.widgets]]              # a card of the Overviews and of Desk's Today
    id = "worst-assets"                  # served at <prefix>api/widgets/<id> (docs/widgets.md)
    title = "Worst assets"
    size = "m"
    kind = "list"                        # number, list, split, series or facts
    default = true
    # pick = "Asset"                     # about one thing the person picks (<id>/options)

    [contributes.search]                 # answers <prefix>api/search (Ctrl+K)
    types = ["Block", "Algorithm", "Loop"]

    [[contributes.calendar]]             # a feed of dated items in Desk's calendar
    id = "reviews"
    title = "Loop reviews"

    [[contributes.todo]]                 # a kind of to-do the app may give people
    id = "review-schedule"
    title = "Review a schedule"

    [[contributes.refs]]                 # #protocol:<id> in messages, actions and notes
    kind = "protocol"
    title = "Algorithm"
    url = "/link/algorithms/{id}"

    [[contributes.settings]]             # an installation setting, drawn in Setup > Apps
    key = "workers"
    title = "Workers"
    type = "integer"
    default = 2
    min = 1
    max = 16

    [[contributes.setup]]                # a page of the app listed in PlantCraft's Setup
    title = "Sources"
    path = "/hist/sources"

    [contributes]
    queue = true                         # answers <prefix>api/queue (the suite's work queues)

    [[contributes.assistant.works]]      # what the assistant does on one of the app's pages
    id = "new-block"                     # the work linkcraft:new-block
    pages = ["blocks", "block-new"]      # the page ids the app's pages name in useAssistantPage
    kind = "create"                      # "ask": reads and explains; "create": proposes an object
    title = "Create a block with the assistant"
    instructions = "Collect the block's name, inputs, outputs and formula, then propose it."
    object = "block"
    create = "/link/api/blocks"          # POSTed with the person's session when they click Create
    open = "/link/blocks/{id}"           # the new object's page ("id" of the route's answer)
    [[contributes.assistant.works.fields]]
    key = "name"
    title = "Name"
    required = true

    [[publishes.series]]                 # series written to the Historian, in its format
    name = "{schedule}.{output}"
    title = "Schedule outputs"
    type = "number"
    per = "asset"
    retention = "app"

Every table is checked here (``processcraft-app check`` runs it in CI): unknown keys, repeated
ids and out-of-range values are errors. Only fields are ever added to these tables; PlantCraft
skips, with a warning, a table it does not know (an app newer than the platform), and tells
apps what it offers in ``GET /api/v1/installation`` (``features``).
"""

from __future__ import annotations

import re
from collections.abc import Mapping
from typing import Annotated, Any, Literal

from pydantic import BaseModel, ConfigDict, Field, StringConstraints, model_validator

from processcraft_sdk.events import EventSpec, parse_specs

# The version of the [contributes] tables PlantCraft reads; a new field never changes it.
CONTRIBUTES_VERSION = 1

# What a PlantCraft names in ``features`` of ``GET /api/v1/installation`` (SDK 0.31.0): the
# tables of [contributes] it draws today. An app hides what its platform lacks.
FEATURES = (
    "contributions",
    "llm",
    "widgets",
    "search",
    "calendar",
    "todo",
    "refs",
    "settings",
    "setup",
    "queue",
    "series",
    "assistant",
)

SLUG = r"^[a-z][a-z0-9-]{0,40}$"
# A reference kind of the suite (processcraft.refs): letters and "_", no digits.
REF_KIND = r"^[a-z][a-z_]{1,31}$"
# Kinds PlantCraft owns; an app names its own objects.
PLATFORM_REF_KINDS = (
    "action",
    "app",
    "asset",
    "conversation",
    "event",
    "execution",
    "group",
    "job",
    "loop",
    "note",
    "run",
    "signal",
    "todo",
    "user",
)
SETTING_KEY = r"^[a-z][a-z0-9_]{0,39}$"
# The kinds of value a Historian point holds (apps/historian kinds.py) and the series per run.
SERIES_TYPES = ("number", "integer", "boolean", "text", "instant", "structured", "run_series")
SERIES_NAME = re.compile(r"^[a-z{][a-z0-9_.{}-]{0,79}$")

Slug = Annotated[str, StringConstraints(pattern=SLUG)]
Title = Annotated[str, StringConstraints(min_length=1, max_length=120, strip_whitespace=True)]
Description = Annotated[str, StringConstraints(max_length=600, strip_whitespace=True)]
# A path on the suite's host: "/" first, no scheme, host or "..".
Path = Annotated[str, StringConstraints(pattern=r"^/[A-Za-z0-9._~/{}-]{0,199}$")]


class _Table(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True, str_strip_whitespace=True)


def _once(items: list[Any], field: str, what: str) -> None:
    names = [getattr(item, field) for item in items]
    twice = sorted({name for name in names if names.count(name) > 1})
    if twice:
        raise ValueError(f"{what} declared more than once: {', '.join(twice)}")


class LlmUse(_Table):
    """A use of a language model: PlantCraft lists it in Setup > Language models, where an
    administrator picks its model (or the default, or off); the app calls it through the
    platform (``POST /api/v1/llm/<app id>:<id>``) and never holds a key."""

    id: Slug
    title: Title
    description: Description = ""
    # What the use sends to the model, in words, for the administrator who decides.
    reads: Description = ""
    default: Literal["default", "off"] = "default"


class WidgetSize(_Table):
    w: int = Field(ge=1, le=12)
    h: int = Field(ge=1, le=3)


class Widget(_Table):
    """A widget of the app's Overview and PlantCraft's boards; its data stays at
    ``<prefix>api/widgets/<id>`` (``docs/widgets.md``)."""

    id: Annotated[str, StringConstraints(pattern=r"^[a-z0-9][a-z0-9-]{0,40}$")]
    title: Title
    description: Description = ""
    size: Literal["s", "m", "l"] = "m"
    sizes: list[WidgetSize] = Field(default_factory=list, max_length=3)
    default: bool = False
    # The shape its data takes (processcraft_sdk.widgets): number, list, split, series, facts.
    kind: Literal["number", "list", "split", "series", "facts"] = "list"
    # A widget about one thing the person picks ("Schedule", "Point"): its choices are served at
    # <prefix>api/widgets/<id>/options and its data at <prefix>api/widgets/<id>?item=<value>.
    pick: Annotated[str, StringConstraints(max_length=40, strip_whitespace=True)] = ""
    # May be placed more than once on one board (always, with ``pick``).
    multiple: bool = False


class Search(_Table):
    """The app answers ``<prefix>api/search``; ``types`` are the kinds of object it finds."""

    types: list[Title] = Field(default_factory=list, max_length=20)


class CalendarFeed(_Table):
    """A feed of dated items the app keeps in Desk's calendar (``PUT /api/v1/calendar/<id>``)."""

    id: Slug
    title: Title
    description: Description = ""
    # Shown to a person until they hide it; false: a chip they switch on.
    visible: bool = True


class TodoKind(_Table):
    """A kind of to-do the app may give a person or a group (``POST /api/v1/todos``)."""

    id: Slug
    title: Title
    description: Description = ""


class RefKind(_Table):
    """A kind of reference the app owns (``#<kind>:<id>``): PlantCraft asks
    ``<prefix>api/refs/<kind>/<id>`` for its name and state, and links ``url``."""

    kind: Annotated[str, StringConstraints(pattern=REF_KIND)]
    title: Title
    # The object's page; "{id}" is replaced by the reference's id.
    url: Path

    @model_validator(mode="after")
    def _own(self) -> RefKind:
        if self.kind in PLATFORM_REF_KINDS:
            raise ValueError(f"reference kind {self.kind!r} belongs to PlantCraft")
        if "{id}" not in self.url:
            raise ValueError('url holds "{id}", where the reference\'s id goes')
        return self


class Setting(_Table):
    """An installation setting of the app, drawn by PlantCraft in Setup > Apps and read by the
    app at ``GET /api/v1/contributions/settings``. Work settings (a rule's limits) stay in the
    app's own pages."""

    key: Annotated[str, StringConstraints(pattern=SETTING_KEY)]
    title: Title
    help: Description = ""
    type: Literal["text", "number", "integer", "boolean", "choice"] = "text"
    default: str | int | float | bool | None = None
    options: list[Title] = Field(default_factory=list, max_length=30)
    min: float | None = None
    max: float | None = None
    unit: Annotated[str, StringConstraints(max_length=20)] = ""
    # Only an administrator reads it back (a token, a password); never shown again.
    secret: bool = False

    @model_validator(mode="after")
    def _typed(self) -> Setting:
        if self.type == "choice":
            if not self.options:
                raise ValueError(f"setting {self.key!r} of type choice lists its options")
            if self.default is not None and self.default not in self.options:
                raise ValueError(f"default of {self.key!r} is one of its options")
        elif self.options:
            raise ValueError(f"only a setting of type choice has options ({self.key!r})")
        if self.default is not None:
            expected = {
                "text": (str,),
                "number": (int, float),
                "integer": (int,),
                "boolean": (bool,),
                "choice": (str,),
            }[self.type]
            if not isinstance(self.default, expected) or (
                self.type in ("number", "integer") and isinstance(self.default, bool)
            ):
                raise ValueError(f"default of {self.key!r} is a {self.type}")
        if self.min is not None and self.max is not None and self.min > self.max:
            raise ValueError(f"min of {self.key!r} is not above its max")
        if (self.min is not None or self.max is not None) and self.type not in (
            "number",
            "integer",
        ):
            raise ValueError(f"only a number has min and max ({self.key!r})")
        return self


def setting_value(spec: Setting | Mapping[str, Any], value: Any) -> Any:
    """``value`` checked against the setting it is for (its type, options, min and max); None
    clears it (the app reads its default again). Raises ValueError with a sentence to show."""

    setting = spec if isinstance(spec, Setting) else Setting.model_validate(dict(spec))
    if value is None:
        return None
    kind = setting.type
    if kind == "boolean":
        if not isinstance(value, bool):
            raise ValueError(f"{setting.title} is on or off.")
        return value
    if kind in ("number", "integer"):
        if isinstance(value, bool) or not isinstance(value, int | float):
            raise ValueError(f"{setting.title} is a number.")
        if kind == "integer":
            if float(value) != int(value):
                raise ValueError(f"{setting.title} is a whole number.")
            value = int(value)
        if setting.min is not None and value < setting.min:
            raise ValueError(f"{setting.title} is {setting.min:g} at least.")
        if setting.max is not None and value > setting.max:
            raise ValueError(f"{setting.title} is {setting.max:g} at most.")
        return value
    if not isinstance(value, str):
        raise ValueError(f"{setting.title} is a text.")
    if kind == "choice" and value not in setting.options:
        raise ValueError(f"{setting.title} is one of: {', '.join(setting.options)}.")
    if len(value) > 2000:
        raise ValueError(f"{setting.title} has 2,000 characters at most.")
    return value


class SetupPage(_Table):
    """A page of the app PlantCraft's Setup lists (the app's sources, its alarm philosophy)."""

    title: Title
    path: Path
    description: Description = ""


class SeriesSpec(_Table):
    """Series the app writes to the Historian, in the Historian's format (``docs/api-v1.md``,
    "Data layer"). ``name`` is the pattern of the point names (``{schedule}.{output}``)."""

    name: Annotated[str, StringConstraints(pattern=SERIES_NAME.pattern)]
    title: Title
    description: Description = ""
    type: Literal[SERIES_TYPES] = "number"  # type: ignore[valid-type]
    unit: Annotated[str, StringConstraints(max_length=20)] = ""
    # What one point is about: an asset (a result asset under it), a signal, or the app.
    per: Literal["asset", "signal", "app"] = "asset"
    # Who sets how long it is kept: the app (per point, managed_by), else the Historian's
    # default; a number of days (0: forever) fixes it.
    retention: Literal["app", "historian"] | Annotated[int, Field(ge=0, le=36500)] = "historian"


WORK_FIELD_TYPES = (
    "text",
    "long_text",
    "number",
    "integer",
    "boolean",
    "choice",
    "date",
    "datetime",
    "list",
)
# Access levels of the suite (processcraft.auth.access), lowest first.
LEVELS = ("viewer", "editor", "admin")


class WorkField(_Table):
    """A field of the object a "create" work proposes. The assistant asks for it, the platform
    checks the proposal with these rules (``check_fields``) and the person sees it on the card;
    the app's own route still checks the object when the person clicks Create."""

    key: Annotated[str, StringConstraints(pattern=SETTING_KEY)]
    title: Title
    help: Description = ""
    type: Literal[WORK_FIELD_TYPES] = "text"  # type: ignore[valid-type]
    required: bool = False
    options: list[Annotated[str, StringConstraints(min_length=1, max_length=120)]] = Field(
        default_factory=list, max_length=60
    )
    max_length: int = Field(default=2000, ge=1, le=20000)
    min: float | None = None
    max: float | None = None

    @model_validator(mode="after")
    def _typed(self) -> WorkField:
        if (self.type == "choice") != bool(self.options):
            raise ValueError(f"field {self.key!r}: a choice lists its options, other types none")
        if (self.min is not None or self.max is not None) and self.type not in (
            "number",
            "integer",
        ):
            raise ValueError(f"only a number has min and max ({self.key!r})")
        return self


class AssistantWork(_Table):
    """Something the assistant does on some of the app's pages (owner, 2026-10-25): it reads and
    explains (``ask``) or collects fields and proposes an object the person creates with one click
    (``create``; the model itself never writes). ``docs/assistant.md``, "Works"."""

    id: Slug
    pages: list[Slug] = Field(min_length=1, max_length=20)
    kind: Literal["ask", "create"] = "ask"
    title: Title
    hint: Description = ""
    # What the model is asked to do (the person can read it: "See the context").
    instructions: Annotated[
        str, StringConstraints(min_length=1, max_length=2000, strip_whitespace=True)
    ]
    # The person completes the question first ("Which signal?").
    ask: Annotated[str, StringConstraints(max_length=120, strip_whitespace=True)] = ""
    # The lowest access level offered the work. A "create" work says the level its route takes
    # (an editor for shared objects, a viewer for their own, like a calendar event); the route
    # checks it again when the person clicks Create.
    level: Literal[LEVELS] = "viewer"  # type: ignore[valid-type]
    object: Annotated[str, StringConstraints(max_length=60, strip_whitespace=True)] = ""
    fields: list[WorkField] = Field(default_factory=list, max_length=40)
    create: Path | None = None
    open: Path | None = None
    # Or, for an object a person finishes in its own form (a block's code, an algorithm's
    # diagram): the page the card's button opens with the fields as a draft; the person saves there.
    form: Path | None = None

    @model_validator(mode="after")
    def _kind(self) -> AssistantWork:
        _once(self.fields, "key", f"field of work {self.id!r}")
        if self.kind == "create":
            if not (self.object and self.fields and (self.create or self.form)):
                raise ValueError(
                    f"create work {self.id!r} names its object, fields and create route or form"
                )
            if self.create and self.form:
                raise ValueError(f"create work {self.id!r} has a create route or a form, not both")
            if self.form and self.open:
                raise ValueError(f"the form of {self.id!r} opens the object itself (no open)")
            if self.open is not None and "{id}" not in self.open:
                raise ValueError(f'open of {self.id!r} holds "{{id}}"')
        elif self.fields or self.create or self.open or self.form:
            raise ValueError(f"only a create work has fields, create, open and form ({self.id!r})")
        return self


class AssistantOffer(_Table):
    """One of PlantCraft's works the app offers on some of its pages, such as creating an action
    from an alarm: the work and its create route stay PlantCraft's, the page is the app's."""

    work: Slug
    pages: list[Slug] = Field(min_length=1, max_length=20)


class AssistantTable(_Table):
    works: list[AssistantWork] = Field(default_factory=list, max_length=60)
    offers: list[AssistantOffer] = Field(default_factory=list, max_length=20)

    @model_validator(mode="after")
    def _unique(self) -> AssistantTable:
        _once(self.works, "id", "assistant work")
        _once(self.offers, "work", "offered work")
        return self


def fields_schema(fields: list[WorkField] | list[Mapping[str, Any]]) -> dict[str, Any]:
    """The JSON Schema of a create work's fields, for the model's ``propose`` tool."""

    properties: dict[str, Any] = {}
    required: list[str] = []
    for raw in fields:
        field = raw if isinstance(raw, WorkField) else WorkField.model_validate(dict(raw))
        kind = {
            "number": {"type": "number"},
            "integer": {"type": "integer"},
            "boolean": {"type": "boolean"},
            "list": {"type": "array", "items": {"type": "string"}},
            "date": {"type": "string", "format": "date"},
            "datetime": {"type": "string", "format": "date-time"},
            "choice": {"type": "string", "enum": list(field.options)},
        }.get(field.type, {"type": "string", "maxLength": field.max_length})
        description = field.title + (f": {field.help}" if field.help else "")
        properties[field.key] = {**kind, "description": description}
        if field.required:
            required.append(field.key)
    return {
        "type": "object",
        "properties": properties,
        "required": required,
        "additionalProperties": False,
    }


def check_fields(
    fields: list[WorkField] | list[Mapping[str, Any]], values: Any
) -> tuple[dict[str, Any], list[str]]:
    """A proposal's values checked against the work's fields: the clean values and the problems,
    one sentence each (missing, unknown, wrong type, not an option, out of range)."""

    specs = [
        raw if isinstance(raw, WorkField) else WorkField.model_validate(dict(raw)) for raw in fields
    ]
    if not isinstance(values, Mapping):
        return {}, ["The proposal is an object of fields."]
    known = {field.key: field for field in specs}
    problems = [f"Unknown field {key!r}." for key in values if key not in known]
    clean: dict[str, Any] = {}
    for field in specs:
        value = values.get(field.key)
        if value is None or value == "" or value == []:
            if field.required:
                problems.append(f"{field.title} ({field.key}) is required.")
            continue
        problem = _field_problem(field, value)
        if problem:
            problems.append(problem)
        else:
            clean[field.key] = value
    return clean, problems


def _field_problem(field: WorkField, value: Any) -> str:
    kind = field.type
    wrong = f"{field.title} ({field.key}) is a {kind.replace('_', ' ')}."
    if kind == "boolean":
        return "" if isinstance(value, bool) else wrong
    if kind in ("number", "integer"):
        if not isinstance(value, int | float) or isinstance(value, bool):
            return wrong
        if kind == "integer" and float(value) != int(value):
            return wrong
        if field.min is not None and value < field.min:
            return f"{field.title} is {field.min:g} at least."
        if field.max is not None and value > field.max:
            return f"{field.title} is {field.max:g} at most."
        return ""
    if kind == "list":
        ok = isinstance(value, list) and all(isinstance(item, str) for item in value)
        return "" if ok else wrong
    if not isinstance(value, str):
        return wrong
    if len(value) > field.max_length:
        return f"{field.title} has {field.max_length} characters at most."
    if kind == "choice" and value not in field.options:
        return f"{field.title} is one of: {', '.join(field.options)}."
    if kind == "date" and not re.match(r"^\d{4}-\d{2}-\d{2}$", value):
        return f"{field.title} is a date (YYYY-MM-DD)."
    if kind == "datetime" and not re.match(r"^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}", value):
        return f"{field.title} is a date and time (ISO 8601)."
    return ""


class ContributesTable(_Table):
    llm: list[LlmUse] = Field(default_factory=list, max_length=20)
    widgets: list[Widget] = Field(default_factory=list, max_length=20)
    search: Search | None = None
    calendar: list[CalendarFeed] = Field(default_factory=list, max_length=10)
    todo: list[TodoKind] = Field(default_factory=list, max_length=20)
    refs: list[RefKind] = Field(default_factory=list, max_length=20)
    settings: list[Setting] = Field(default_factory=list, max_length=50)
    setup: list[SetupPage] = Field(default_factory=list, max_length=10)
    queue: bool = False
    assistant: AssistantTable | None = None

    @model_validator(mode="after")
    def _unique(self) -> ContributesTable:
        _once(self.llm, "id", "llm use")
        _once(self.widgets, "id", "widget")
        _once(self.calendar, "id", "calendar feed")
        _once(self.todo, "id", "to-do kind")
        _once(self.refs, "kind", "reference kind")
        _once(self.settings, "key", "setting")
        _once(self.setup, "path", "setup page")
        return self


class ContributionsIn(BaseModel):
    """The body of ``PUT /api/v1/contributions``: what one app adds, replaced whole."""

    model_config = ConfigDict(extra="ignore")

    app: Annotated[str, StringConstraints(min_length=1, max_length=40)] | None = None
    version: Annotated[str, StringConstraints(max_length=60)] = ""
    format: int = CONTRIBUTES_VERSION
    contributes: ContributesTable = ContributesTable()
    series: list[SeriesSpec] = Field(default_factory=list, max_length=50)
    events: list[EventSpec] = Field(default_factory=list, max_length=100)

    @model_validator(mode="before")
    @classmethod
    def _known_tables(cls, data: Any) -> Any:
        # A newer app may send tables this SDK does not know: keep the known ones, list the rest.
        if isinstance(data, Mapping) and isinstance(data.get("contributes"), Mapping):
            known = set(ContributesTable.model_fields)
            given = dict(data["contributes"])
            data = {
                **data,
                "contributes": {key: value for key, value in given.items() if key in known},
                "unknown": sorted(set(given) - known),
            }
        return data

    unknown: list[str] = Field(default_factory=list)

    @model_validator(mode="after")
    def _once(self) -> ContributionsIn:
        _once(self.series, "name", "series")
        _once(self.events, "name", "event")
        return self


def contributions(manifest: Any) -> dict[str, Any]:
    """The body of ``PUT /api/v1/contributions`` from a parsed ``AppManifest`` or ``app.toml``
    read as a dict."""

    if isinstance(manifest, Mapping):
        app = dict(manifest.get("app") or {})
        publishes = dict(manifest.get("publishes") or {})
        body = ContributionsIn.model_validate(
            {
                "app": app.get("id"),
                "version": app.get("version") or "",
                "contributes": manifest.get("contributes") or {},
                "series": publishes.get("series") or [],
                "events": [
                    spec.model_dump(mode="json")
                    for spec in parse_specs(publishes.get("events") or [])
                ],
            }
        )
    else:
        body = ContributionsIn(
            app=manifest.app.id,
            version=manifest.app.version,
            contributes=manifest.contributes,
            series=list(manifest.publishes.series),
            events=list(manifest.publishes.events),
        )
    return body.model_dump(mode="json", exclude_none=True, exclude={"unknown"})


__all__ = [
    "AssistantTable",
    "AssistantWork",
    "CONTRIBUTES_VERSION",
    "CalendarFeed",
    "ContributesTable",
    "ContributionsIn",
    "FEATURES",
    "LlmUse",
    "PLATFORM_REF_KINDS",
    "RefKind",
    "SERIES_TYPES",
    "Search",
    "SeriesSpec",
    "Setting",
    "SetupPage",
    "TodoKind",
    "WORK_FIELD_TYPES",
    "Widget",
    "WorkField",
    "check_fields",
    "contributions",
    "fields_schema",
    "setting_value",
]
