"""PlantCraft SDK: what an app of the suite needs to talk to PlantCraft.

- ``processcraft_sdk.jwt``: Ed25519 JSON Web Tokens and JWK helpers.
- ``processcraft_sdk.auth``: verify the user's token on every request (FastAPI/Starlette).
- ``processcraft_sdk.client``: typed client for every endpoint of API v1.
- ``processcraft_sdk.assets``: the asset model (types, attributes, roles, relations, starter types).
- ``processcraft_sdk.refs``: ``parse_ref``/``format_ref`` for asset, signal, person and run references.
- ``processcraft_sdk.links``: shapes and rules of results, events, runs and schedules.
- ``processcraft_sdk.app_manifest``: the ``app.toml`` model; ``processcraft-app check`` runs it.
- ``processcraft_sdk.methods``: the ``@method`` decorator and the method contracts.
- ``processcraft_sdk.blocks``: blocks with typed, described ports and algorithms as diagrams of
  them: the contract, the diagram checks and runs, and the one format of their descriptions.
- ``processcraft_sdk.prompts``: prompts for an AI assistant (the "Copy as prompt" buttons), with
  no secret or endpoint in them.
- ``processcraft_sdk.testing``: ``FakeProcessCraft``, an in-process API v1 for app tests.
- ``processcraft_sdk.server``: what every app server has in common (its SQLite store, ``app.toml``
  and help pages, access checks and the web application under its prefix).
- ``processcraft_sdk.sbom``: the SPDX SBOM of an app's image (``processcraft-app sbom``).
- For app tests (``docs/testing.md``): ``apptest`` (the suite's rules as checks), ``testplant``
  (the Simulator's loops served by a fake), ``e2e`` (browser journeys), ``pytest_budget`` (the
  test time budget, a pytest plugin).
"""

__version__ = "0.41.0"
